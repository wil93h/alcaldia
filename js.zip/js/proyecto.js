$(document).ready(function(){
  alert("Uso jQuery");
  $("#img1").attr("src","../../../img/portfolio/item2.jpg");
  $("#img1_1").attr("href","../../../img/portfolio/item2.jpg");

  $("#img2").attr("src","../../../img/portfolio/item2.jpg");
  $("#img2_1").attr("href","../../../img/portfolio/item2.jpg");

  $("#img3").attr("src","../../../img/portfolio/item2.jpg");
  $("#img3_1").attr("href","../../../img/portfolio/item2.jpg");

  $("#img4").attr("src","../../../img/portfolio/item2.jpg");
  $("#img4_1").attr("href","../../../img/portfolio/item2.jpg");

  $("#img5").attr("src","../../../img/portfolio/item2.jpg");
  $("#img5_1").attr("href","../../../img/portfolio/item2.jpg");

  $("#img6").attr("src","../../../img/portfolio/item2.jpg");
  $("#img6_1").attr("href","../../../img/portfolio/item2.jpg");
});
